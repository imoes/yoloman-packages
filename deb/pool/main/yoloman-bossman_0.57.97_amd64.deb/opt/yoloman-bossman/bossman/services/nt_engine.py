"""Block G11 (NT format, step 4): run a NestedText runbook against a host.

Orders the steps, evaluates `when:` (sandboxed Jinja2, via when_eval), expands
`loop:`, substitutes variables (nt_vars: real Jinja2 `{{ }}` + the legacy
$v / ${v} / ${v:-default} shim) against the running context, runs each `module`
on the agent via call_tool, threads `register`ed results AND `set_fact` facts
into the shared namespace (so later steps can template on them, like Ansible),
and honours check-mode (dry-run: modules get dry_run=true and never mutate).

Pure orchestration over the AgentClient.call_tool interface, so it's unit-
tested with a fake client and needs no live host. Variable scopes are merged
GPO-style by the caller (nt_vars.merge_scopes); registered results share the
namespace with variables, exactly like Ansible.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from bossman.services.nt_runbook import Runbook, Step
from bossman.services.nt_vars import substitute
from bossman.services.when_eval import WhenError, eval_when


@dataclass
class StepResult:
    name: str
    module: str
    status: str                      # ok | changed | skipped | failed
    item: Any = None
    changed: bool | None = None
    error: str = ""
    response: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        d = {"name": self.name, "module": self.module, "status": self.status,
             "changed": self.changed, "response": self.response}
        if self.item is not None:
            d["item"] = self.item
        if self.error:
            d["error"] = self.error
        return d


@dataclass
class RunResult:
    check_mode: bool
    steps: list[StepResult] = field(default_factory=list)
    aborted: bool = False

    @property
    def changed(self) -> bool:
        return any(s.changed for s in self.steps)

    @property
    def ok(self) -> bool:
        return not any(s.status == "failed" for s in self.steps) and not self.aborted

    def to_dict(self) -> dict[str, Any]:
        return {"check_mode": self.check_mode, "ok": self.ok, "changed": self.changed,
                "aborted": self.aborted, "steps": [s.to_dict() for s in self.steps]}


def _resolve_loop(step: Step, context: dict[str, Any]) -> list[Any]:
    """[None] when no loop (single iteration); a literal list as-is; a string
    is a dotted path into the context that must resolve to a list."""
    if step.loop is None:
        return [None]
    if isinstance(step.loop, list):
        return list(step.loop)
    value: Any = context
    for part in str(step.loop).strip().lstrip("${").rstrip("}").split("."):
        if not isinstance(value, dict) or part not in value:
            raise WhenError(f"loop {step.loop!r} is not defined")
        value = value[part]
    if not isinstance(value, list):
        raise WhenError(f"loop {step.loop!r} did not resolve to a list")
    return value


def _summarize_register(results: list[StepResult], looped: bool) -> dict[str, Any]:
    """The value stored under a step's `register` name — a single result's
    response for a plain step, or a {results, changed, ok} rollup for a loop
    (so later `when:` can reference name.changed / name.results)."""
    if not looped:
        r = results[-1]
        return {**r.response, "changed": bool(r.changed), "ok": r.status != "failed"}
    return {
        "results": [r.response for r in results],
        "changed": any(bool(r.changed) for r in results),
        "ok": all(r.status != "failed" for r in results),
    }


def _nest_dotted(values: dict[str, Any]) -> dict[str, Any]:
    """`{"server.host_name": "x"}` → also `{"server": {"host_name": "x"}}`, which is how the template reads it.

    Schemas name nested settings by dotted path (avahi-daemon's `server.host_name`); the template addresses them as
    attributes. Passed flat, `{{ server.host_name }}` found no `server` and the render failed — 38 of 298 catalog
    roles in the Bossman-path e2e. The flat keys stay, so nothing that read them changes."""
    out = dict(values)
    for key, value in values.items():
        if not isinstance(key, str) or "." not in key:
            continue
        head, *rest = key.split(".")
        node = out.setdefault(head, {})
        if not isinstance(node, dict):
            continue
        for part in rest[:-1]:
            node = node.setdefault(part, {})
            if not isinstance(node, dict):
                break
        else:
            node.setdefault(rest[-1], value)
    return out


async def _apply_config_template(
    step: Any, args: dict[str, Any], item: Any, client: Any,
    variables: dict[str, Any], templates: dict[str, str], check_mode: bool,
) -> StepResult:
    """The `config_template` step: render a named config template (e.g. apache2
    vhost) to a destination file. The template body is handed to the agent as a
    template_render config resource — the agent renders the Jinja2 with `values`
    (the runbook variables overlaid with the step's own `vars`)."""
    name = args.get("template") or args.get("name")
    dest = args.get("dest") or args.get("path")
    # The family's own template for THIS file wins over the named one: a role names one template, but the
    # RedHat file and the Debian file of one software are different files (see config_templates.family_key).
    family = variables.get("_family")
    body = templates.get(f"@{family}:{dest}") if family and dest else None
    if body is None:
        body = templates.get(name) if name else None
        # A template records the file it renders. Written over a DIFFERENT file it replaces that file's content with
        # another file's — measured: cups rendered its snmp.conf template over cupsd.conf, opendmarc its
        # /etc/default snippet over opendmarc.conf. Refused, with both paths named; nothing is written.
        recorded = templates.get(f"@target:{name}") if name else None
        if body is not None and dest and recorded and recorded != dest:
            return StepResult(name=step.name, module=step.module, status="failed", item=item,
                              error=f"refused: template {name!r} renders {recorded}, but this host's file is {dest}")
    if name and not dest:
        # A catalog role whose branch for THIS family names no configuration file (`_dest` empty): the package is
        # installed, the file is not configured — said, not failed. It used to abort the whole role (18 of 298
        # roles in the Bossman-path e2e) although the install itself was fine.
        return StepResult(name=step.name, module=step.module, status="skipped", item=item,
                          error="this role names no configuration file for the host's family — installed, not configured")
    if not name or not dest:
        return StepResult(name=step.name, module=step.module, status="failed", item=item,
                          error="config_template needs `template` (name) and `dest` (path)")
    if any(ch in dest for ch in "*?["):
        # A pattern is not a file. Written literally it created a directory named `*` (php-fpm on Debian:
        # /etc/php/*/fpm/pool.d/www.conf) while the daemon kept its real file — and the read-back of that same
        # path reported "compliant" (Bossman-path e2e). Refused, with the pattern named.
        return StepResult(name=step.name, module=step.module, status="failed", item=item,
                          error=f"refused: the destination {dest!r} is a pattern, not a file — the catalog must "
                                "name the concrete path for this host")
    if body is None:
        return StepResult(name=step.name, module=step.module, status="failed", item=item,
                          error=f"unknown config template {name!r}")
    merged = {**variables, **(args.get("vars") or {})}
    # A field only ANOTHER family's file has (the role's form is the union of its families' templates): a value the
    # operator set for it on this host would be written nowhere. Refused, naming the fields and where they apply.
    family_only = variables.get("_family_only") or {}
    role_defaults_all = variables.get("_role_defaults") or {}
    foreign = sorted(k for k, fams in family_only.items()
                     if family and family not in fams and k in merged and merged[k] != role_defaults_all.get(k))
    if foreign:
        where = sorted({f for k in foreign for f in family_only[k]})
        return StepResult(name=step.name, module=step.module, status="failed", item=item,
                          error=f"refused: {', '.join(foreign)} exist(s) only in the {'/'.join(where)} file — this "
                                f"host is {family}; leave them unset for it")
    if family and templates.get(f"@{family}:{dest}") is not None:
        # A FAMILY template renders with the role's variables, whose defaults are the role's (Debian) values: on
        # AlmaLinux php-fpm got `user = www-data`, a user that does not exist there. A value still equal to the role
        # default is not a choice — it is dropped, so the family template's own default (its with_own_defaults
        # prelude) applies. A value the operator changed is kept. (An operator who wants exactly the Debian
        # default on RedHat gets the RedHat default instead — the price of not knowing who typed it.)
        role_defaults = variables.get("_role_defaults") or {}
        merged = {k: v for k, v in merged.items()
                  if k.startswith("_") or k not in role_defaults or role_defaults[k] != v}
        # A value the operator SET for a field this family's file does not have would vanish silently — squid on EL
        # ships 3 directives where Debian documents 207. Refused, naming the fields, instead of a "compliant" host
        # that ignores what was asked.
        named = set(re.findall(r"[A-Za-z_]\w*", body))
        lost = sorted(k for k in merged if k in role_defaults and not k.startswith("_") and k not in named)
        if lost:
            return StepResult(name=step.name, module=step.module, status="failed", item=item,
                              error=f"refused: this host's {family} file has no setting for {', '.join(lost)} — the "
                                    "value(s) would be lost; leave them unset for this family or add them to its template")
    values = _nest_dotted({k: v for k, v in merged.items() if k not in ("_role_defaults", "_family_only")})
    resource = {"type": "template_render", "path": dest, "template": body, "values": values}
    try:
        resp = await client.state_apply({"resources": [resource]}, check_mode)
        # The agent answers `{"plan": {"changes": [...], "changed_count": n}, "generation": …}` — in BOTH modes.
        # Reading a top-level `changes` (which the agent never sends) made every config_template step report
        # "unchanged": an edited managed file was "compliant" forever, and a config change notified no handler.
        # The top-level form stays accepted for older agents.
        plan = (resp.get("plan") or {}) if isinstance(resp, dict) else {}
        changes = (resp.get("changes") if isinstance(resp, dict) else None) or plan.get("changes") or []
        changed = any(c.get("action") not in (None, "noop") for c in changes)
        return StepResult(name=step.name, module=step.module, status=("changed" if changed else "ok"),
                          item=item, changed=changed, response=resp if isinstance(resp, dict) else {"result": resp})
    except Exception as exc:  # noqa: BLE001 — recorded, not raised
        return StepResult(name=step.name, module=step.module, status="failed", item=item, error=str(exc))


def _tag_selected(tags: list[str], only: set[str] | None, skip: set[str] | None) -> bool:
    """Ansible tag selection: `always`-tagged steps always run (unless skipped);
    a step is skipped if its tags intersect skip_tags (or `all` is skipped); with
    only_tags set, a step runs only if its tags intersect it (or `all` is asked)."""
    t = set(tags or [])
    if "always" in t and not (skip and "always" in skip):
        return True
    if skip and (t & skip or "all" in skip):
        return False
    if only:
        return bool(t & only) or "all" in only
    return True


async def run_runbook(
    runbook: Runbook,
    client: Any,
    variables: dict[str, Any] | None = None,
    *,
    check_mode: bool = False,
    templates: dict[str, str] | None = None,
    only_tags: set[str] | None = None,
    skip_tags: set[str] | None = None,
) -> RunResult:
    """Run `runbook` against `client` (an AgentClient). `variables` is the
    already-GPO-merged variable scope. Returns a RunResult recording every
    step; a failed step with ignore_errors=false aborts the rest. `only_tags`/
    `skip_tags` gate which steps run (Ansible `--tags`/`--skip-tags`)."""
    variables = dict(variables or {})
    # Shared namespace for when:/register (like Ansible): starts as the vars.
    context: dict[str, Any] = dict(variables)
    out = RunResult(check_mode=check_mode)
    # Handler names notified by a `changed` step, in first-notified order.
    notified: list[str] = []

    for step in runbook.steps:
        if await _run_task(step, client, context, variables, templates or {}, check_mode,
                           only_tags, skip_tags, notified, out):
            out.aborted = True
            return out

    # Handlers: each notified handler runs once, in definition order, after all
    # tasks (like Ansible). A play that aborted above never reaches here.
    for h in runbook.handlers:
        if h.name not in notified:
            continue
        out.steps.append(await _run_handler(h, client, context, variables, templates or {}, check_mode))

    return out


async def _run_task(
    step: Step, client: Any, context: dict[str, Any], variables: dict[str, Any],
    templates: dict[str, str], check_mode: bool, only_tags: set[str] | None,
    skip_tags: set[str] | None, notified: list[str], out: "RunResult",
) -> bool:
    """Run one task — a normal step or a block (block/rescue/always). Appends
    result rows to `out`; returns True iff the run should abort."""
    # tags: a task not selected this run is silently omitted (no result row).
    if not _tag_selected(step.tags, only_tags, skip_tags):
        return False
    # when: — a false condition skips the whole task (never a failure).
    if step.when is not None:
        try:
            if not eval_when(step.when, context):
                out.steps.append(StepResult(name=step.name, module=step.module, status="skipped"))
                return False
        except WhenError as exc:
            out.steps.append(StepResult(name=step.name, module=step.module, status="failed", error=f"when: {exc}"))
            return not step.ignore_errors
    if step.module == "block":
        return await _run_block(step, client, context, variables, templates, check_mode,
                                only_tags, skip_tags, notified, out)
    return await _run_step(step, client, context, variables, templates, check_mode, notified, out)


async def _run_block(
    block: Step, client: Any, context: dict[str, Any], variables: dict[str, Any],
    templates: dict[str, str], check_mode: bool, only_tags: set[str] | None,
    skip_tags: set[str] | None, notified: list[str], out: "RunResult",
) -> bool:
    """block/rescue/always (Ansible): run the block; on a hard failure run the
    rescue tasks (which can recover); always tasks run regardless."""
    async def _run_all(tasks: list[Step]) -> bool:
        for child in tasks:
            if await _run_task(child, client, context, variables, templates, check_mode,
                               only_tags, skip_tags, notified, out):
                return True
        return False

    aborted = await _run_all(block.block)
    if aborted and block.rescue:
        aborted = await _run_all(block.rescue)   # rescue may recover (or fail again)
    if block.always and await _run_all(block.always):
        aborted = True                           # a failing always task aborts the run
    return aborted and not block.ignore_errors


#: Modules whose result is a process exit code. Ansible fails them on a non-zero rc; so does this engine.
_RC_MODULES = frozenset({"command", "shell", "script", "raw"})


def _failure(module: str, resp: dict) -> str | None:
    """Why a module call failed, or None when it did not — ONE rule for steps and handlers.

    A command that exits non-zero has failed (Ansible's semantics), even though the agent reports it as
    "executed": measured in the package e2e, `nginx -t` returned rc=1 on a broken nginx.conf, the step counted as
    changed, the runbook went on to restart nginx with that file, and the host was left with a stopped web server.
    `ignore_errors` on the step still lets a caller accept a non-zero rc deliberately."""
    if resp.get("failed") or "error" in resp:
        return str(resp.get("error", "") or "failed")
    if module in _RC_MODULES:
        data = resp.get("data") if isinstance(resp.get("data"), dict) else {}
        rc = data.get("rc")
        if isinstance(rc, int) and rc != 0:
            detail = str(data.get("stderr") or data.get("stdout") or "").strip()[-400:]
            return f"exit code {rc}" + (f": {detail}" if detail else "")
    return None


async def _run_step(
    step: Step, client: Any, context: dict[str, Any], variables: dict[str, Any],
    templates: dict[str, str], check_mode: bool, notified: list[str], out: "RunResult",
) -> bool:
    """Run one non-block step (loop / set_fact / config_template / call_tool +
    register + notify). Appends result rows to `out`; returns True iff aborting."""
    items = _resolve_loop(step, context)
    looped = step.loop is not None
    iteration_results: list[StepResult] = []
    aborted = False

    for item in items:
        # Substitute against the running context (vars + registered results +
        # set_facts), not just the initial vars — so a later step can template
        # on an earlier step's registered result, like Ansible.
        subst = dict(context)
        if item is not None:
            subst["item"] = item
        args = substitute(step.args, subst)
        # set_fact is a controller-side op (like Ansible): fold the resolved facts
        # into the shared namespace so later when:/loop:/{{ }} see them.
        if step.module == "set_fact":
            context.update(args)
            sr = StepResult(name=step.name, module="set_fact", status="ok",
                            item=item, changed=False, response={"ansible_facts": dict(args)})
            iteration_results.append(sr)
            out.steps.append(sr)
            continue
        # A config_template step renders a named template to a file via the
        # agent's template_render apply, instead of a generic tool call.
        if step.module == "config_template":
            sr = await _apply_config_template(step, args, item, client, variables, templates, check_mode)
        else:
            body = {**args, "dry_run": True} if check_mode else dict(args)
            try:
                resp = await client.call_tool(step.module, body)
                if not isinstance(resp, dict):
                    resp = {"result": resp}
                changed = resp.get("changed")
                error = _failure(step.module, resp)
                status = "failed" if error is not None else ("changed" if changed else "ok")
                sr = StepResult(name=step.name, module=step.module, status=status,
                                item=item, changed=changed, response=resp, error=error or "")
            except Exception as exc:  # noqa: BLE001 — a module failure is recorded, not raised
                sr = StepResult(name=step.name, module=step.module, status="failed",
                                item=item, error=str(exc))
        iteration_results.append(sr)
        out.steps.append(sr)
        if sr.status == "failed" and not step.ignore_errors:
            aborted = True
            break

    if step.register:
        context[step.register] = _summarize_register(iteration_results, looped)
    # notify: a step that changed queues its handlers (Ansible fires on change).
    if not aborted and step.notify and any(r.status == "changed" for r in iteration_results):
        for n in step.notify:
            if n not in notified:
                notified.append(n)
    return aborted


async def _run_handler(
    h: Step, client: Any, context: dict[str, Any], variables: dict[str, Any],
    templates: dict[str, str], check_mode: bool,
) -> StepResult:
    """Run a single notified handler (no loop; when/args/set_fact/config_template
    honoured, mirroring a normal step)."""
    if h.when is not None:
        try:
            if not eval_when(h.when, context):
                return StepResult(name=h.name, module=h.module, status="skipped")
        except WhenError as exc:
            return StepResult(name=h.name, module=h.module, status="failed", error=f"when: {exc}")
    args = substitute(h.args, dict(context))
    if h.module == "set_fact":
        context.update(args)
        return StepResult(name=h.name, module="set_fact", status="ok", response={"ansible_facts": dict(args)})
    if h.module == "config_template":
        return await _apply_config_template(h, args, None, client, variables, templates, check_mode)
    body = {**args, "dry_run": True} if check_mode else dict(args)
    try:
        resp = await client.call_tool(h.module, body)
        if not isinstance(resp, dict):
            resp = {"result": resp}
        changed = resp.get("changed")
        error = _failure(h.module, resp)
        status = "failed" if error is not None else ("changed" if changed else "ok")
        return StepResult(name=h.name, module=h.module, status=status, changed=changed,
                          response=resp, error=error or "")
    except Exception as exc:  # noqa: BLE001 — recorded, not raised
        return StepResult(name=h.name, module=h.module, status="failed", error=str(exc))
