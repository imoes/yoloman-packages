"""path → config template: the explicit index that replaces a basename guess.

WHY THIS EXISTS. The UI used to answer "does this config file have a template?" by taking the path's
basename minus .conf and looking for a template directory of that name. That is a guess from name
similarity, and it was measurably wrong: /etc/aardvark-dns/aardvark-dns.conf resolved to the template
dir `aardvark-dns`, which renders /etc/aardvark-dns/FORWARD.conf — a different file of the same
package. Since the Configure write path is template_render (WHOLE FILE, no merge), the "Edit via
template" button would have written one file's content over another.

It also made the host page download GET /config-templates in full — 33.7 MB of template bodies across
5460 directories — to perform a string comparison. This index is a few hundred kB of path→name pairs.

THREE GROUNDED SOURCES, and the precedence is deliberate:

  1. package_catalog.json — a role's own `template` together with its `families.debian.config_path`.
     Curated or measured, and the only one the withdrawal rule has been applied to, so a template known
     NOT to configure its own file is already `null` here. 55 paths.

  2. config_codecs.json — every non-glob path of a codec entry whose derived template dir exists. The
     template's name and the file's basename agree by construction here, which is direct evidence.

  3. the template's own meta.json `target_path` — a RECORDED fact rather than a derivation, written by
     scripts/backfill_template_target.py. It exists because the library and the resolver disagree about
     what a directory NAME means: the batch names a directory after the PACKAGE it processed, while this
     index resolves by FILE. Measured before it: 2786 of 5460 template dirs were unreachable by anything,
     2071 of them simply because no codec key's basename matched their name.

Source 1 wins where they disagree — measured 20 times, e.g. /etc/haproxy/haproxy.cfg where the role
offers `haproxy` and the codec key offers `haproxy.cfg`. BOTH DIRS EXIST: that is two templates for one
file, the same duplication as the 278 underscore/hyphen twin dirs on a different axis. The index does
not hide it — `conflicts` reports every case, because a resolution nobody can see is indistinguishable
from a coincidence.

AND A BINDING WHOSE TARGET IS NOT A CONFIG FILE IS WITHDRAWN TOO. The path measurement answers "is there a
file", never "is it a SETTING". Measured on the bindings the editor offers today: 27 of them target something
that is not configuration —

    /etc/cron.daily/logrotate, /etc/X11/Xsession.d/90xbrlapi   run-parts EXECUTES these; a whole-file render
                                                               replaces a working script with a rendered one
    /etc/apparmor.d/local/README, /etc/arp-scan/mac-vendor.txt  documentation and a vendor table

That is the same damage class as the sshd/pam.d case the catalog already guards against: the write path is
whole-file, so pressing Configure on /etc/cron.daily/logrotate breaks daily log rotation. The refusal is a
DECISION recorded in `withdrawn`, not an accident of the index not looking — 225 further templates in the
corpus record such a target and are unreachable today only because nothing binds them, which a later
improvement to this resolver would silently undo.

Deliberately NOT refused: /etc/cron.d/* (a crontab fragment IS config, unlike /etc/cron.daily/* which holds
scripts), /etc/logrotate.d/*, and config written in a programming language — /etc/phpmyadmin/config.inc.php,
/etc/prosody/prosody.cfg.lua and LocalSettings.php are the applications' real configuration, and a rule that
refused ".php" would remove correct bindings to win an argument about file extensions.

AND A BINDING WHOSE PATH DOES NOT EXIST IS WITHDRAWN, reported in `withdrawn` rather than dropped. The
registry says how a file is written, never whether there is one: bindings named a path the package ships
nothing at, because the path was derived from the package NAME (/etc/aide, /etc/bind, /etc/ttygif). Configure
writes the whole file, so pressing it would create a new file in /etc that looks configured and that no
software reads. Measured per path by scripts/verify_registry_paths.py.

A verdict only withdraws when the CORPUS also has no file at that path (`exists_elsewhere`). The measurement
ran on Debian, and "absent from this package on this distro" is not "no such file": /etc/named.conf is absent
from Debian's bind9 and present on EL. 0 of 1920 name-derived absences appear in the corpus; 51 of 494 real
config-path absences do.

Glob paths are excluded on purpose. "/etc/php/*/fpm/pool.d/www.conf" identifies a SET of files; an
index entry claiming one template for a set would answer a question nobody asked.
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path

from bossman.services.snapin_owned import SNAPIN_OWNED as SNAPIN_ONLY_PATHS, snapin_for
from bossman.services.template_gate import DirectorySet, plausible_target, template_configures

#: Same normalisation the catalog builder uses for a template directory name, so the index cannot
#: disagree with the thing it indexes. Kept here rather than imported: scripts/ is not on the server's
#: import path, and one small regex duplicated is cheaper than a sys.path hack in a request handler.
_SAFE = re.compile(r"[^A-Za-z0-9._-]")


def _template_name(key: str) -> str:
    base = key.rsplit("/", 1)[-1] or key
    return _SAFE.sub("-", base) or "config"


#: In-process cache: {(catalog, codecs, templates_dir): (built_at, signature, index)}.
#:
#: Gating every entry means reading 5460 template bodies and schemas, which took the build from 41 ms to
#: 560 ms — and this endpoint sits in the host page's load path. The signature covers the two JSON inputs
#: (mtime + size) and the template root's own mtime and entry count, so adding, removing or rewriting a
#: catalog/codec file is picked up at once.
#:
#: The TTL is the honest part: editing a template.j2 IN PLACE changes neither the root dir's mtime nor
#: its entry count, so that one change is invisible to the signature. 60 seconds bounds how long a
#: freshly-broken template can still be offered, or a freshly-fixed one stay hidden. The batch that
#: writes templates runs for hours, so a minute is noise there; a page load is not.
_CACHE: dict[tuple, tuple[float, tuple, dict]] = {}
_TTL_SECONDS = 60.0


def _signature(catalog_path: Path, codecs_path: Path, tpl_root: Path) -> tuple:
    def _stat(p: Path) -> tuple:
        try:
            st = p.stat()
            return (st.st_mtime_ns, st.st_size)
        except OSError:
            return (0, 0)

    try:
        count = sum(1 for _ in tpl_root.iterdir())
    except OSError:
        count = -1
    return (_stat(catalog_path), _stat(codecs_path), _stat(tpl_root), count)


#: Directories whose contents run-parts (or an equivalent) EXECUTES. Membership is by directory, not by
#: extension, because that is what makes it certain: a file in /etc/cron.daily is a program by contract,
#: whatever it is called.
#:
#: /etc/cron.d is NOT here and the difference is the whole point — it holds crontab FRAGMENTS (schedule plus
#: command), which are configuration. Nor are /etc/logrotate.d or /etc/apparmor.d, which hold real config
#: grammars.
_RUN_PARTS_DIRS = re.compile(
    r"^/etc/(?:"
    r"cron\.(?:daily|hourly|weekly|monthly)"
    r"|init\.d|rc\d?\.d|rcS\.d"
    r"|network/if-(?:up|down|pre-up|post-down)\.d"
    r"|kernel/(?:postinst|postrm|header_postinst)\.d"
    r"|initramfs/post-update\.d|initramfs-tools/hooks"
    r"|dhcp/dhclient-(?:enter|exit)-hooks\.d"
    r"|apm/(?:event|scripts|suspend|resume)\.d"
    r"|X11/Xsession\.d|update-motd\.d|grub\.d"
    r"|NetworkManager/dispatcher\.d"
    r")/")

#: Documentation and data tables. You do not configure a README, and rendering one over it loses the text.
_NOT_A_SETTING = re.compile(
    r"(?:^|/)(?:README|readme|CHANGELOG|Changelog|ChangeLog|NEWS|COPYING|LICENSE|AUTHORS|TODO)[^/]*$"
    r"|\.(?:md|rst|txt|html?)$")

#: A Perl module — code a program imports. Kept narrow ON PURPOSE: .php/.lua/.py are how several applications
#: WRITE their configuration (config.inc.php, prosody.cfg.lua, LocalSettings.php), and refusing an extension
#: would remove correct bindings to win an argument about file names.
_SOURCE_CODE = re.compile(r"\.pm$")


#: Key material and trust anchors — a signing key, a CA bundle, a certificate. Measured 2026-10-15: 8 bindings, e.g.
#: elrepo-release-redhat on /etc/pki/elrepo/SECURE-BOOT-KEY-elrepo.org.der (binary) and unbound-anchor on
#: /etc/unbound/icannbundle.pem. A whole-file render would replace the key with text; certificates and keys come by
#: reference from the password store, not as template values.
_KEY_MATERIAL = re.compile(r"\.(?:der|gpg|asc|pem|crt|cer|key|p12|pfx|jks|keystore)$|/trusted\.gpg\.d/")


def unsuitable_target(path: str) -> str | None:
    """Why this path must not be offered as an editable config file, or None when it may be.

    Separate from the path VERDICT, which answers whether a file exists there. Both questions have to be
    asked: /etc/cron.daily/logrotate exists, is measured `file`, and is a program.
    """
    if _NOT_A_SETTING.search(path):
        return ("this is documentation, not a setting — Configure writes the whole file, so it would "
                "replace the text with a rendered template")
    if _SOURCE_CODE.search(path):
        return ("this is program source code (a Perl module), not a config file — a whole-file render "
                "would replace code the program imports")
    if _KEY_MATERIAL.search(path):
        return ("this is key material or a trust anchor (a key, certificate or CA bundle), not a setting — a "
                "whole-file render would replace it with text; keys come by reference from the password store")
    if _RUN_PARTS_DIRS.search(path):
        return ("run-parts EXECUTES the files in this directory, so this is a program rather than a "
                "setting — a whole-file render would replace a working script with a rendered one")
    return None


def build_template_index(catalog_path: str | Path, codecs_path: str | Path,
                         templates_dir: str | Path, family: str = "",
                         verdicts_path: str | Path | None = None) -> dict:
    """Return {"paths": {path: {"template": name, "source": "catalog"|"codec"}}, "conflicts": [...]}.

    Each input is passed explicitly rather than derived from a configs root: the codec registry has its
    own setting (`config_codecs_path`) and need not sit next to the catalog, and a function that guesses
    where its inputs live is a function that silently indexes the wrong ones.

    Pure and cheap (two file reads plus one directory listing). Missing or unreadable inputs yield an
    empty index rather than an error: no index means no Configure button, which is the safe direction —
    the alternative would be resolving by name again.
    """
    tpl_root, cat_p, cod_p = Path(templates_dir), Path(catalog_path), Path(codecs_path)
    ver_p = Path(verdicts_path) if verdicts_path else cat_p.parent / "config_path_verdicts.json"
    key = (str(cat_p), str(cod_p), str(tpl_root), family, str(ver_p))
    wrong_p = ver_p.parent / "template_differs_reasons.json"
    sig = (_signature(cat_p, cod_p, tpl_root) + _signature(ver_p, ver_p, tpl_root)[:1]
           + _signature(wrong_p, wrong_p, tpl_root)[:1])
    hit = _CACHE.get(key)
    if hit and hit[1] == sig and time.monotonic() - hit[0] < _TTL_SECONDS:
        return hit[2]

    dirs = {d.name for d in tpl_root.iterdir() if d.is_dir()} if tpl_root.is_dir() else set()
    # EVERY entry passes the gate, both sources. Source 1 is filtered upstream too (a withdrawn
    # template is already `null` in the catalog), but source 2 had NO filter at all: measured, 437 of
    # 3488 codec-sourced paths pointed at a template the gate refuses — shell scripts, ufw profiles,
    # unparameterised texts. Each one offered "Edit via template" on a file whose Apply writes a fixed
    # text over the live config. False is refused; None (cannot be judged) is kept, because withholding
    # every unjudgeable editor would remove working ones, and that asymmetry is the gate's own.
    ok = {name: template_configures(tpl_root, name) is not False for name in dirs}
    refused_by_gate = sorted(name for name in dirs if not ok[name])
    dirs = {name for name in dirs if ok[name]}

    def _load(path: str | Path) -> dict:
        try:
            data = json.loads(Path(path).read_text())
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}

    paths: dict[str, dict] = {}
    conflicts: list[dict] = []

    # Every template's OWN record, read once and shared by all three sources below. Source 3 used to read
    # these files itself; sources 1 and 2 never asked, which is exactly how the index came to contradict its
    # own artifacts.
    metas: dict[str, dict] = {}
    for name in sorted(dirs):
        try:
            data = json.loads((tpl_root / name / "meta.json").read_text())
        except (OSError, ValueError):
            continue
        if isinstance(data, dict):
            metas[name] = data

    # Which files each catalog role's template renders, on any family (patterns are not files).
    catalog_claims: dict[str, set[str]] = {}
    for _role, _entry in _load(catalog_path).items():
        if isinstance(_entry, dict) and _entry.get("template"):
            for _fe in (_entry.get("families") or {}).values():
                _cfg = (_fe or {}).get("config_path") if isinstance(_fe, dict) else None
                if isinstance(_cfg, str) and _cfg and not any(ch in _cfg for ch in "*?["):
                    catalog_claims.setdefault(_entry["template"], set()).add(_cfg)

    def renders(name: str, path: str) -> bool:
        """Would binding `name` to `path` contradict what that template says about itself?

        MEASURED on the live index: 203 of 3611 bindings named a template whose own meta.json records a
        DIFFERENT target_path. /etc/ansible/hosts was bound to the template `hosts`, which records
        /etc/hosts — pressing Configure would have written the machine's hosts file over an Ansible
        inventory. /etc/cups/cupsd.conf was bound to `cups`, whose template.j2 is cups' snmp.conf, while
        `cups-redhat` (witness: rpm) records cupsd.conf exactly.

        Sources 1 and 2 bind by NAME — a catalog role name or a codec key that happens to match a directory.
        A name match is a hypothesis; `target_path` is a record. Where the two disagree the record wins, and
        the name-based binding is refused so the path stays free for whoever really claims it. A template
        with no record is not refused: most of the library predates the field, and refusing everything
        unrecorded would empty the index.
        """
        own = metas.get(name, {}).get("target_path")
        if isinstance(own, str):
            return own == path
        # THE CATALOG IS A RECORD TOO. A role's template is the renderer of the file the catalog names for it, on
        # whichever family — even where a family template has since taken that path over. Measured on the
        # recorded index: 23 codec bindings handed a role template a file that merely shares its NAME —
        # `cron` (crontab) on /etc/pam.d/cron and /etc/default/cron, `haproxy` (haproxy.cfg) on
        # /etc/sysconfig/haproxy and /etc/logrotate.d/haproxy, `redis` on /etc/raddb/mods-available/redis.
        # The cross-source sweep below did not catch them: on RedHat the catalog path belongs to the -redhat
        # template, so what was left of `haproxy` were two paths of ONE basename. The same file in another
        # location (same basename as a catalog path) stays allowed.
        claimed = catalog_claims.get(name)
        if claimed:
            return path in claimed or path.rsplit("/", 1)[-1] in {c.rsplit("/", 1)[-1] for c in claimed}
        return True

    def record_of(name: str) -> str:
        own = metas.get(name, {}).get("target_path")
        if isinstance(own, str):
            return own
        return " / ".join(sorted(catalog_claims.get(name) or [])) + " (its catalog role)"

    # Precomputed ONCE: plausible_target asks "is this a directory", which is membership in the set of
    # ancestors of every known path. Asked as a linear scan per candidate it cost this endpoint 4.1 s after the
    # registry grew to 11573 entries — and it is in the host page's load path.
    known = DirectorySet.of(
        p for e in _load(codecs_path).values() if isinstance(e, dict)
        for p in (e.get("paths") or []) if isinstance(p, str))

    # Source 1 — the catalog. First, so it owns every path it claims.
    for role, entry in _load(catalog_path).items():
        if not isinstance(entry, dict):
            continue
        tname = entry.get("template")
        cfg = ((entry.get("families") or {}).get("debian") or {}).get("config_path") or ""
        if not tname or not cfg or tname not in dirs or not plausible_target(cfg, known):
            continue
        if not renders(tname, cfg):
            conflicts.append({"path": cfg, "chosen": None, "chosen_source": "catalog",
                              "also": tname, "also_source": "catalog",
                              "reason": "refused: template {} records target {}".format(
                                  tname, record_of(tname))})
            continue
        paths.setdefault(cfg, {"template": tname, "source": "catalog", "role": role})

    # Every candidate path is checked by ONE rule (template_gate.plausible_target): under /etc, not a
    # glob, not an ancillary location, not a directory. The audit found three paths in the index that no
    # renderer could ever write — /etc/bind and /etc/ovn-controller-vtep (directories, with their real
    # config files sitting right beside them in the same registry) and /etc/default/policyd-weight (a
    # SysV defaults snippet). The resolver had always refused those; this source never asked.
    # Source 2 — the codec registry, as the fallback.
    #
    # NOT named `key`: that is the cache key three lines up, and shadowing it stored the result under
    # the last codec entry's name instead. The cache then never hit, which the timing showed (three
    # calls, 520 ms each) and reading would not have.
    # Declared here rather than beside the verdict loop: the codec binding above also withdraws, and a list
    # that comes into existence halfway down the function cannot be appended to from the first half.
    withdrawn: list[dict] = []
    for codec_key, entry in _load(codecs_path).items():
        if not isinstance(entry, dict):
            continue
        tname = _template_name(codec_key)
        if tname not in dirs:
            continue
        # ONE TEMPLATE RENDERS ONE FILE, and a codec entry may list many. Measured: the entry keyed
        # `apparmor.d` carries 259 paths — /etc/apparmor.d/1password, /Discord, /MongoDB_Compass … — and
        # every one of them was bound to the single `apparmor.d` template, so pressing Configure on Discord's
        # profile would have rendered a generic skeleton over it. `logrotate.conf` did the same to 17
        # logrotate fragments. This is the mirror image of the conflict rule below (two templates for one
        # path) and nothing was asking it.
        #
        # THE SAME BASENAME IN SEVERAL LOCATIONS IS FINE and must stay: /etc/magic, /etc/apache2/magic and
        # /etc/httpd/conf/magic are the same file in three places, which is 114 of the 130 multi-path
        # templates. What is refused is a group of DIFFERENT files sharing one renderer.
        candidates = [p for p in (entry.get("paths") or [])
                      if isinstance(p, str) and plausible_target(p, known)]
        basenames = {p.rsplit("/", 1)[-1] for p in candidates}
        if len(basenames) > 1:
            # Keep only the file this template is actually named after; refuse the rest by name.
            keep = {p for p in candidates if p.rsplit("/", 1)[-1] == codec_key.rsplit("/", 1)[-1]}
            for p in candidates:
                if p not in keep:
                    withdrawn.append({
                        "path": p, "template": tname, "source": "codec", "verdict": "not-this-template",
                        "package": None,
                        "reason": "the codec entry {!r} lists {} files with {} different names and this "
                                  "template renders one of them; Configure writes the WHOLE file, so "
                                  "offering it here would render another file's content over this one"
                                  .format(codec_key, len(candidates), len(basenames))})
            candidates = sorted(keep)

        for p in candidates:
            if not renders(tname, p):
                conflicts.append({"path": p, "chosen": None, "chosen_source": "codec",
                                  "also": tname, "also_source": "codec",
                                  "reason": "refused: template {} records target {}".format(
                                      tname, record_of(tname))})
                continue
            have = paths.get(p)
            if have is None:
                paths[p] = {"template": tname, "source": "codec"}
            elif have["template"] != tname:
                # Reported, never silently merged: two template dirs render the same file, and which
                # one is right is a question about their CONTENT, not something precedence settles.
                conflicts.append({"path": p, "chosen": have["template"], "chosen_source": have["source"],
                                  "also": tname, "also_source": "codec"})

    # Source 3 — the template's OWN record of what it renders (meta.json target_path), written by
    # scripts/backfill_template_target.py and, going forward, by the pipeline that generates the
    # template. Third in precedence because the catalog and the registry are the curated statements;
    # this one exists because a template directory is named after a PACKAGE while the index resolves by
    # FILE, so more than half the library — 2786 of 5460 dirs — was unreachable by anything.
    #
    # A recorded fact, not a derivation: the file says which path it is for, so nothing here has to
    # guess from the name. Directories whose target is AMBIGUOUS carry `ambiguous_with` and no
    # target_path (190 paths are claimed by 509 templates — 21 ejabberd modules all configure sections
    # of one ejabberd.yml), and they are skipped exactly because they were not resolved.
    for name, meta in sorted(metas.items()):
        p = meta.get("target_path")
        if not isinstance(p, str) or not plausible_target(p, known):
            continue
        # A template recorded for ANOTHER family is that family's file. Building the index for a known family, it
        # is not offered: measured, the debian block bound 297 `-redhat` templates (grep-redhat on
        # /etc/GREP_COLORS, alsa-utils-redhat on /etc/alsa/alsactl.conf) — Configure on a Debian host would have
        # written the RPM's file. Named, not dropped. Without a family (base) it stays as before.
        if family and meta.get("family") and meta["family"] != family:
            withdrawn.append({"path": p, "template": name, "source": "template-meta", "verdict": "other-family",
                              "package": None,
                              "reason": "template {} renders the {} file; this index is for {} hosts".format(
                                  name, meta["family"], family)})
            continue
        have = paths.get(p)
        if have is None:
            # `family` only when the template records one — an empty key on every entry would be noise, and
            # the comparison below reads a missing key as "no family" anyway.
            paths[p] = {"template": name, "source": "template-meta"}
            if meta.get("family"):
                paths[p]["family"] = meta["family"]
        elif have["template"] != name:
            # SAME PATH, TWO DISTRIBUTIONS. /etc/caddy/Caddyfile is that path on both families and the two
            # files differ, so precedence alone would render Debian's over a RedHat host's. When the CALLER
            # knows the family — only a host does; this index is otherwise host-independent by design — the
            # matching template wins and the loser is still reported. Without a family, nothing changes: the
            # earlier claim stands and the clash is a conflict, which is the honest answer to a question
            # nobody has asked precisely enough.
            mine = meta.get("family") or ""
            # A RECORD BEATS A NAME. The incumbent came from source 1 or 2, which bind because a catalog role
            # or a codec key happens to share a directory name; this template states its target and carries
            # a witness for it (`deb`/`rpm` = read out of the package, `corpus-text` = its literal text was
            # matched against the shipped file). Measured: 265 paths were held by a name binding while a
            # witnessed record for the exact path sat unused — /etc/collectd.conf went to the Debian dir
            # `collectd.conf`, which shares 0% of EL's 988-line collectd.conf, while `collectd` matches it.
            # A record that declares a FAMILY is not used to override without one being asked for: that is
            # the /etc/caddy/Caddyfile case, where overriding blind would hand a Debian host EL's file.
            witnessed = meta.get("witness") in ("deb", "rpm", "corpus-text")
            # The catalog counts as a record of its role template's file (see renders()): /etc/samba/smb.conf
            # went from the catalog's `samba` to the `smb.conf` directory when the latter gained a witnessed
            # target, although the catalog had chosen `samba` for exactly that path.
            incumbent_recorded = (isinstance(metas.get(have["template"], {}).get("target_path"), str)
                                  or p in catalog_claims.get(have["template"], set()))
            if witnessed and not incumbent_recorded and (not mine or mine == family):
                conflicts.append({"path": p, "chosen": name, "chosen_source": "template-meta",
                                  "also": have["template"], "also_source": have["source"],
                                  "reason": "recorded target (witness {}) beats a name binding".format(
                                      meta.get("witness"))})
                paths[p] = {"template": name, "source": "template-meta"}
                if mine:
                    paths[p]["family"] = mine
            elif family and mine == family and have.get("family") != family:
                conflicts.append({"path": p, "chosen": name, "chosen_source": "template-meta",
                                  "also": have["template"], "also_source": have["source"],
                                  "reason": "family {} matches the host".format(family)})
                paths[p] = {"template": name, "source": "template-meta", "family": mine}
            else:
                conflicts.append({"path": p, "chosen": have["template"], "chosen_source": have["source"],
                                  "also": name, "also_source": "template-meta"})

    # A snap-in that owns the file gets the last word. EXCLUSIVE means the generic whole-file editor is not
    # offered for that path at all — named.conf has zones, smb.conf has shares, nginx.conf has server
    # blocks, and rendering any of them from a flat form drops whatever the form has no field for. The
    # entry stays in the index rather than disappearing: the UI needs to say WHICH snap-in is in charge,
    # and a path that silently vanished would look like "no editor exists".
    for path, entry in paths.items():
        owned = snapin_for(path)
        if owned:
            entry["snapin"], entry["snapin_label"], entry["snapin_exclusive"] = owned
    # The ownership table is returned SEPARATELY rather than injected into `paths`. My first version added
    # an entry per owned path with `template: null`, which made `paths` mean two things at once — "the
    # template that renders this file" and "a snap-in owns this file, no template involved" — and nine
    # tests said so immediately by finding paths in an index built from empty fixtures. One key, one
    # meaning: `paths` is templates, `snapins` is ownership, and an entry in `paths` carries the ownership
    # annotation when both apply.
    snapins = {path: {"snapin": o[0], "snapin_label": o[1], "snapin_exclusive": o[2]}
               for path, o in ((p, snapin_for(p)) for p in SNAPIN_ONLY_PATHS) if o}

    # A BINDING TO A PATH NOTHING SHIPS IS WITHDRAWN. Measured by extracting the real packages
    # (scripts/verify_registry_paths.py): of 3563 bindings, 1562 named a path that does not exist as a file.
    # This matters more here than anywhere else, because Configure writes the WHOLE file — pressing it would
    # CREATE /etc/aide (a directory in the package; the real config is /etc/aide.conf) and fill it with a
    # rendered text no software reads. Not a cosmetic wrong answer: a new file, in /etc, that looks
    # configured and is inert.
    #
    # THREE VERDICTS WITHDRAW, and one deliberately does not:
    #   directory / dangling-symlink   there is something there and it is not a writable file
    #   absent WITHOUT a maintainer script naming it   nothing accounts for this path at all
    #   absent WITH one                KEPT: a config created at install time is a real file on a real
    #                                  host, merely missing from the archive.
    # Unmeasured paths are also kept — absence of a measurement is not a measurement of absence, and
    # withdrawing everything unproven would remove thousands of working editors.
    verdicts = _load(ver_p)
    # THE SECOND GUARD: files no package owns because the SYSTEM creates them. Measured by asking the package
    # manager itself in a base image (scripts/find_unowned_base_files.py): 34 of debian:12's 106 /etc files
    # belong to no package — /etc/hostname, /etc/fstab, /etc/passwd, /etc/shells, /etc/timezone,
    # /etc/nsswitch.conf, the pam.d/common-* stack. Every one is a real, editable config on every host, and
    # every one gets an "absent" verdict because no archive contains it. Without this, the withdrawal removed
    # the editor for the machine's own hostname.
    unowned = _load(ver_p.parent / "config_unowned_paths.json")
    # NOT A CONFIG FILE — asked BEFORE the path verdict, and it has to be asked separately: the verdict
    # answers "is there a file here", and /etc/cron.daily/logrotate exists, measures `file`, and is a program.
    # Same withdrawal shape as the verdict below, so the UI that already shows one shows this too.
    for path in sorted(paths):
        why = unsuitable_target(path)
        if not why:
            continue
        entry = paths.pop(path)
        withdrawn.append({"path": path, "template": entry.get("template"),
                          "source": entry.get("source"), "verdict": "not-configuration",
                          "package": None, "reason": why})

    # THE TEMPLATE RENDERS ANOTHER FILE — measured, not guessed. Stage 5 renders every reachable binding with its
    # defaults and compares it with the file the package ships at that path (tools/template_shipped_fidelity);
    # tools/explain_differs records `wrong-file` where not ONE setting the template writes occurs in that file,
    # active or commented. Measured 2026-10-14: 375 of 1209 differing units — `config.ini` of one application on
    # every config.ini, the `mdadm` template on /etc/logcheck/ignore.d.server/mdadm, ssh_config in
    # /etc/default/ssh. The binding is withdrawn for the family it was measured on (the base index: on any), the
    # catalog's own bindings excepted — a curated binding that renders the wrong file is a catalog defect to fix,
    # not to hide.
    wrong: dict[tuple[str, str], set[str]] = {}
    for unit in (_load(wrong_p).get("units") or {}).values():
        if isinstance(unit, dict) and unit.get("category") == "wrong-file":
            wrong.setdefault((unit.get("template"), unit.get("path")), set()).add(unit.get("family"))
    for path in sorted(paths):
        entry = paths[path]
        fams = wrong.get((entry.get("template"), path))
        if not fams or entry.get("source") == "catalog" or (family and family not in fams):
            continue
        paths.pop(path)
        withdrawn.append({"path": path, "template": entry.get("template"), "source": entry.get("source"),
                          "verdict": "wrong-file", "package": None,
                          "reason": "rendered with its defaults, this template writes no setting the file at this "
                                    "path has (measured against the shipped file on {}); Configure writes the "
                                    "WHOLE file, so it would replace this file with another one".format(
                                        ", ".join(sorted(f for f in fams if f)))})

    for path in sorted(paths):
        seen = verdicts.get(path)
        if not isinstance(seen, dict):
            continue
        # THE FAMILY'S OWN MEASUREMENT WINS when this index is being built for a family, exactly as
        # /config-fields prefers the codec's by_family branch. Of 83 paths measured on both distributions 20
        # disagree — /etc/named.conf is absent from Debian's bind9 and a real file on EL — so a single answer
        # is wrong for one of them. The top level is the conservative aggregate (any family that found a file
        # makes it "file"), which is the right default for the host-independent base index.
        branch = (seen.get("by_family") or {}).get(family) if family else None
        measured_here = isinstance(branch, dict) and bool(branch.get("verdict"))
        if measured_here:
            seen = {**seen, **branch}
        verdict = seen.get("verdict")
        # THE FALSIFICATION POINT. A verdict is evidence about ONE package on ONE distribution, and the
        # measurement ran in a debian:12 container. `exists_elsewhere` says the corpus has real text at this
        # path, so the file demonstrably exists — under another package, or on the other distro.
        # /etc/named.conf is absent from Debian's bind9 (Debian puts it in /etc/bind/) and /etc/openldap/
        # ldap.conf is EL's location for Debian's /etc/ldap/ldap.conf. Measured: 0 of 1920 absent verdicts for
        # NAME-DERIVED paths appear in the corpus, but 51 of 494 from the real-config-path run do. Without this
        # guard those 51 editors would have been withdrawn for files that are on every host.
        # ...and it applies ONLY where this family was not measured directly. It was always a proxy for "we do
        # not know which distribution this host is", and where the branch above answers, we do. On a Debian
        # host /etc/named.conf really is not there — Debian's bind9 reads /etc/bind/named.conf — so offering
        # Configure would create a file the daemon ignores. The corpus proving it exists ON EL is not a reason
        # to offer it HERE.
        if seen.get("exists_elsewhere") and not measured_here:
            continue
        # THE VERDICT MUST BE ABOUT THIS PATH. It answers "does package P contain X", so when P is not the
        # package that ships X the answer is true about P and says nothing about X. Measured: 72 of 79
        # non-file verdicts whose path is in the corpus name the wrong package — /etc/os-release was measured
        # in `distrobox` (it belongs to base-files), /etc/crontab in `cronie` (crontabs). A direct measurement
        # of the wrong subject is not evidence, so it must not beat the corpus.
        shipped_by = seen.get("shipped_by")
        if isinstance(shipped_by, list) and shipped_by and seen.get("package") not in shipped_by:
            continue
        owner = unowned.get(path)
        if isinstance(owner, dict) and not owner.get("container_artifact"):
            continue
        if verdict == "not-a-path":
            continue      # the key is a basename; nothing was measured about a file
        if verdict in ("directory", "dangling-symlink") or (
                verdict == "absent" and not seen.get("postinst_mentions")):
            entry = paths.pop(path)
            # NOTHING VANISHES SILENTLY: the withdrawal is reported with its template, its reason and the
            # package it was measured in, exactly like `conflicts`. A binding that just disappeared would be
            # indistinguishable from one that never existed, and the next batch run would recreate it.
            withdrawn.append({"path": path, "template": entry.get("template"),
                              "source": entry.get("source"), "verdict": verdict,
                              "package": seen.get("package"),
                              "reason": "package {} ships no file at this path ({}, measured on {}) and no "
                                        "harvested package ships one either; Configure writes the whole "
                                        "file, so it would create one nothing reads".format(
                                            seen.get("package"), verdict,
                                            seen.get("family") or "debian")})

    # ONE TEMPLATE, ONE FILE — the cross-source sweep, after all three sources have bound.
    #
    # The codec loop above stops a single codec entry from spraying one template over 259 files. This catches
    # the same damage assembled from DIFFERENT sources: the catalog binds `nginx` to /etc/nginx/nginx.conf
    # (curated, measured) while the codec registry also binds it to /etc/logrotate.d/nginx — so Configure on
    # the logrotate fragment would render nginx.conf over it. Measured: 14 templates, all of the same shape,
    # every extra path a /etc/default/*, /etc/logrotate.d/*, /etc/pam.d/* or /etc/logcheck/* file that merely
    # shares the daemon's NAME.
    #
    # The catalog's path wins, because that is the one a person or a measurement chose; failing that, the path
    # whose basename IS the template's name. Same precedence the conflict rule uses, applied to the mirror
    # case. Paths that only differ in LOCATION (/etc/magic, /etc/apache2/magic) are untouched — 114 templates
    # are that, and they are one file in several places.
    by_template: dict[str, list[str]] = {}
    for bound_path, entry in paths.items():
        name = (entry or {}).get("template")
        if name:
            by_template.setdefault(name, []).append(bound_path)
    for name, bound in by_template.items():
        if len({b.rsplit("/", 1)[-1] for b in bound}) < 2:
            continue
        chosen = next((b for b in bound if paths[b].get("source") == "catalog"), None)
        if chosen is None:
            chosen = next((b for b in bound if b.rsplit("/", 1)[-1] == name), None)
        if chosen is None:
            continue          # nothing to prefer: leave it visible rather than pick arbitrarily
        for bound_path in bound:
            if bound_path == chosen:
                continue
            entry = paths.pop(bound_path)
            withdrawn.append({
                "path": bound_path, "template": name, "source": entry.get("source"),
                "verdict": "not-this-template", "package": None,
                "reason": "this template renders {} — the file it is named for and the one the catalog "
                          "records; {} merely shares that name, and Configure writes the WHOLE file"
                          .format(chosen, bound_path)})

    # NAMED, NOT DROPPED: a template the gate refuses never reached the sources above, so a template that records its
    # own target simply was not there — 65 EL family templates (profile.d scripts, `.sample` files, bodies without a
    # placed field) vanished from the redhat index without a word. Listed with the gate's meaning, for its family.
    for name in refused_by_gate:
        try:
            meta = json.loads((tpl_root / name / "meta.json").read_text())
        except (OSError, ValueError):
            continue
        target = meta.get("target_path") if isinstance(meta, dict) else None
        if not isinstance(target, str) or (family and meta.get("family") and meta["family"] != family):
            continue
        withdrawn.append({"path": target, "template": name, "source": "template-meta", "verdict": "not-configurable",
                          "package": None,
                          "reason": "the template gate refuses it — an empty body, a script, a body that cannot render "
                                    "its own sample, or one that places no field: Configure would write a fixed text"})

    result = {"paths": paths, "conflicts": conflicts, "snapins": snapins, "withdrawn": withdrawn}
    _CACHE[key] = (time.monotonic(), sig, result)
    return result
